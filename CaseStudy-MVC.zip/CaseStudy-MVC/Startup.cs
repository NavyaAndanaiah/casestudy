﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(CarNoAllocation.Startup))]
namespace CarNoAllocation
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
