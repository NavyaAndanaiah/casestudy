﻿using CarNoAllocation.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Windows.Forms;

namespace CarNoAllocation.Controllers
{
    public class UserLoginController : Controller
    {
        UserLogin userData = new UserLogin();

        // GET: UserLogin
        public ActionResult Login()
        {
            
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(UserLogin objUser)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    using (dbCarNumberAllotmentSystemEntities1 db = new dbCarNumberAllotmentSystemEntities1())
                    {
                        var ob = db.tblRTODetails.Where(a => a.vUserId.Equals(objUser.vUserId) && a.vPassword.Equals(objUser.vPassword)).FirstOrDefault();
                        var obj = db.tblOwnerDetails.Where(a => a.vUserId.Equals(objUser.vUserId) && a.vPassword.Equals(objUser.vPassword)).FirstOrDefault();
                        if (obj != null)
                        {
                            Session["UserID"] = obj.vUserId.ToString();
                            //Session["UserName"] = obj.vUserName.ToString();
                            return RedirectToAction("Userpage", "tblCarRegistrationDetails");
                        }
                        
                        else if (ob != null)
                        {
                            Session["UserID"] = ob.vUserId.ToString();
                            //Session["UserName"] = obj.vUserName.ToString();

                            return RedirectToAction("Rtopage", "tblRTODetails");
                        }
                        else
                        {
                            MessageBox.Show("Sorry the id or password u have entered is invalid");
                            return RedirectToAction("Login");
                        }
                    }
                }
            }
            catch
            {
                MessageBox.Show("Sorry the id or password u have entered is invalid");
                return RedirectToAction("Login");
            }
            return View(objUser);
        }


        public ActionResult Forgot()
        {
            return View();
        }



        [HttpPost]
        public ActionResult Forgot(ForgotPassword ch)
        {
                if (ch.newPassword == ch.confirmPassword)
                {
                    //string user = Session["abc"].ToString();
                    //var pas = ch.oldPassword;
                    try
                    {

                        dbCarNumberAllotmentSystemEntities1 obj = new dbCarNumberAllotmentSystemEntities1();
                        var obj1 = (from e in obj.tblOwnerDetails
                                    where e.vEmail == ch.vEmail && e.iMobile == ch.iMobileNum
                                    select e).FirstOrDefault();
                        obj1.vPassword = ch.newPassword;
                        obj.SaveChanges();

                        return RedirectToAction("Login", "UserLogin");
                    }
                    catch
                    {
                        ModelState.AddModelError("Error", "Wrong old Password Provided!!");
                        return View();
                    }
                }
                else
                {
                    ModelState.AddModelError("Error", "New Password and confirm Password do not match!!");
                    return View();

                }
            
            

        }



     

    }
}