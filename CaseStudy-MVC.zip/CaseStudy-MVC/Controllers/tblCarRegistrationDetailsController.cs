﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using CarNoAllocation.Models;

namespace CarNoAllocation.Controllers
{
    public class tblCarRegistrationDetailsController : Controller
    {
        private dbCarNumberAllotmentSystemEntities1 db = new dbCarNumberAllotmentSystemEntities1();

        // GET: tblCarRegistrationDetails
        public ActionResult Index()
        {

            var tblCarRegistrationDetails = db.tblCarRegistrationDetails.Include(t => t.tblOwnerDetail);
            return View(tblCarRegistrationDetails.ToList());
        }

        // GET: tblCarRegistrationDetails/Details/5
        public ActionResult Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblCarRegistrationDetail tblCarRegistrationDetail = db.tblCarRegistrationDetails.Find(id);
            if (tblCarRegistrationDetail == null)
            {
                return HttpNotFound();
            }
            return View(tblCarRegistrationDetail);
        }

        // GET: tblCarRegistrationDetails/Create
        public ActionResult Create()
        {
            ViewBag.vUserId = new SelectList(db.tblOwnerDetails, "vUserId", "vFullname");
            return View();
        }

        // POST: tblCarRegistrationDetails/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "vRegistrationNum,vUserId,vUniqueId,vWindshieldNum,vColor,vModel,vCurrentMileage,vManufacturingDate,vChassisNum,vLicenceNum,vStatus")] tblCarRegistrationDetail tblCarRegistrationDetail)
        {
            if (Session["UserID"] != null)
            {
                try
                {
                    tblCarRegistrationDetail.vUniqueId = tblCarRegistrationDetail.vColor.Substring(0, 3) + tblCarRegistrationDetail.vLicenceNum.Substring(0, 4);
                    tblCarRegistrationDetail.vUserId = Session["UserID"].ToString();
                    tblCarRegistrationDetail.vStatus = "Need to be approved by the RTA Officer";
                    db.tblCarRegistrationDetails.Add(tblCarRegistrationDetail);
                    db.SaveChanges();
                    return RedirectToAction("UserPage");
                }
                catch
                {
                    ModelState.AddModelError("Nothing", "Sorry data is improper related to our details");
                }
                ViewBag.vUserId = new SelectList(db.tblOwnerDetails, "vUserId", "vFullname", tblCarRegistrationDetail.vUserId);
                
            }
            return View(tblCarRegistrationDetail);
        }

        // GET: tblCarRegistrationDetails/Edit/5
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblCarRegistrationDetail tblCarRegistrationDetail = db.tblCarRegistrationDetails.Find(id);
            if (tblCarRegistrationDetail == null)
            {
                return HttpNotFound();
            }
            ViewBag.vUserId = new SelectList(db.tblOwnerDetails, "vUserId", "vFullname", tblCarRegistrationDetail.vUserId);
            return View(tblCarRegistrationDetail);
        }

        // POST: tblCarRegistrationDetails/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "vRegistrationNum,vUserId,vUniqueId,vWindshieldNum,vColor,vModel,vCurrentMileage,vManufacturingDate,vChassisNum,vLicenceNum,vStatus")] tblCarRegistrationDetail tblCarRegistrationDetail)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tblCarRegistrationDetail).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.vUserId = new SelectList(db.tblOwnerDetails, "vUserId", "vFullname", tblCarRegistrationDetail.vUserId);
            return View(tblCarRegistrationDetail);
        }

        // GET: tblCarRegistrationDetails/Delete/5
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblCarRegistrationDetail tblCarRegistrationDetail = db.tblCarRegistrationDetails.Find(id);
            if (tblCarRegistrationDetail == null)
            {
                return HttpNotFound();
            }
            return View(tblCarRegistrationDetail);
        }

        // POST: tblCarRegistrationDetails/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            tblCarRegistrationDetail tblCarRegistrationDetail = db.tblCarRegistrationDetails.Find(id);
            db.tblCarRegistrationDetails.Remove(tblCarRegistrationDetail);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
        public ActionResult Userpage()
        {
            
            if (Session["UserID"] != null)
            {
                Session["abc"] = Session["UserID"].ToString();
                return View();
            }
            else
            {
                return RedirectToAction("Login");
            }
        }
    }
}
