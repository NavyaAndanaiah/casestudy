﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using CarNoAllocation.Models;
using System.Windows.Forms;

namespace CarNoAllocation.Controllers
{
    public class tblOwnerDetailsController : Controller
    {
        private dbCarNumberAllotmentSystemEntities1 db = new dbCarNumberAllotmentSystemEntities1();

        // GET: tblOwnerDetails
        public ActionResult Index()
        {
            return View(db.tblOwnerDetails.ToList());
        }

        // GET: tblOwnerDetails/Details/5
        public ActionResult Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblOwnerDetail tblOwnerDetail = db.tblOwnerDetails.Find(id);
            if (tblOwnerDetail == null)
            {
                return HttpNotFound();
            }
            return View(tblOwnerDetail);
        }

        // GET: tblOwnerDetails/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: tblOwnerDetails/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "vFullname,iAge,cGender,vAddress,iMobile,vEmail,vUserId,vPassword")] tblOwnerDetail tblOwnerDetail)
        {
            //if (ModelState.IsValid)
            //{
                tblOwnerDetail.vUserId = tblOwnerDetail.vEmail.Substring(0, 5) + tblOwnerDetail.iMobile.Substring(0, 5);
                tblOwnerDetail.vPassword = System.Web.Security.Membership.GeneratePassword(10, 0);
                db.tblOwnerDetails.Add(tblOwnerDetail);
                db.SaveChanges();
                MessageBox.Show("Thankyou for registering with us. Your user id is "+tblOwnerDetail.vUserId+"and password is "+tblOwnerDetail.vPassword);
                return RedirectToAction("Login","UserLogin");
            //}

            //return View(tblOwnerDetail);
        }

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(UserLogin objUser)
        {
            if (ModelState.IsValid)
            {
                using (dbCarNumberAllotmentSystemEntities1 dba = new dbCarNumberAllotmentSystemEntities1())
                {
                    var obj = dba.tblOwnerDetails.Where(a => a.vUserId.Equals(objUser.vUserId) && a.vPassword.Equals(objUser.vPassword)).FirstOrDefault();
                    if (obj != null)
                    {
                        Session["UserID"] = obj.vUserId.ToString();
                        //Session["UserName"] = obj.vUserName.ToString();
                        return RedirectToAction("Userpage","tblCarRegistrationDetails");
                    }
                    var ob = dba.tblRTODetails.Where(a => a.vUserId.Equals(objUser.vUserId) && a.vPassword.Equals(objUser.vPassword)).FirstOrDefault();
                    if (obj != null)
                    {
                        Session["UserID"] = obj.vUserId.ToString();
                        //Session["UserName"] = obj.vUserName.ToString();  
                        return RedirectToAction("Userpage", "tblCarRegistrationDetails");
                    }
                }
            }
            return View(objUser);
        }

        //public ActionResult UserDashBoard()
        //{
        //    if (Session["UserID"] != null)
        //    {
        //        return View();
        //    }
        //    else
        //    {
        //        return RedirectToAction("Login");
        //    }
        //}


        // GET: tblOwnerDetails/Edit/5
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblOwnerDetail tblOwnerDetail = db.tblOwnerDetails.Find(id);
            if (tblOwnerDetail == null)
            {
                return HttpNotFound();
            }
            return View(tblOwnerDetail);
        }

        // POST: tblOwnerDetails/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "vFullname,iAge,cGender,vAddress,iMobile,vEmail,vUserId,vPassword")] tblOwnerDetail tblOwnerDetail)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tblOwnerDetail).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Userpage","tblCarRegistrationDetails");
            }
            return View(tblOwnerDetail);
        }

        // GET: tblOwnerDetails/Delete/5
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblOwnerDetail tblOwnerDetail = db.tblOwnerDetails.Find(id);
            if (tblOwnerDetail == null)
            {
                return HttpNotFound();
            }
            return View(tblOwnerDetail);
        }

        // POST: tblOwnerDetails/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            tblOwnerDetail tblOwnerDetail = db.tblOwnerDetails.Find(id);
            db.tblOwnerDetails.Remove(tblOwnerDetail);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult showLisence()
        {
            string ab=Session["UserID"].ToString();
            var a = (from e in db.tblCarRegistrationDetails where (e.vUserId == ab) select e).FirstOrDefault();
            ab = a.vUniqueId;

            var b = (from e in db.tblLicenecePlates where (e.vUniqueId == ab) select e).FirstOrDefault();
            
            return View(b);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
        [HttpGet]
        public ActionResult ChangePassword()
        {

            return View();
        }



        [HttpPost]
        public ActionResult ChangePassword(ChnagePassword1 ch)
        {
            
                if (Session["abc"] != null)
                {
                    if (ch.newPassword == ch.ConfirmPassword)
                    {
                        string user = Session["abc"].ToString();
                        var pas = ch.oldPassword;
                        try
                        {

                            dbCarNumberAllotmentSystemEntities1 obj = new dbCarNumberAllotmentSystemEntities1();
                            var obj1 = (from e in obj.tblOwnerDetails
                                        where e.vUserId == user && e.vPassword == pas
                                        select e).FirstOrDefault();
                            obj1.vPassword = ch.newPassword;
                            obj.SaveChanges();

                            return RedirectToAction("Login", "UserLogin");
                        }
                        catch
                        {
                            ModelState.AddModelError("Error", "Wrong old Password Provided!!");
                            return View();
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("Error", "New Password and confirm Password do not match!!");
                        return View();

                    }
                }
            
            else
                return RedirectToAction("Index", "Home");


        }


        public ActionResult ViewDetailsofOwner()
        {
            string id = Session["abc"].ToString();
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            dbCarNumberAllotmentSystemEntities1 obj = new dbCarNumberAllotmentSystemEntities1();
            var ab = db.tblCarRegistrationDetails.Where(m => m.vUserId.Equals(id)).ToList();
            if (obj == null)
            {
                return HttpNotFound();
            }
            return View(ab);
        }
    }
}
