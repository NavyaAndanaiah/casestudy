﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using CarNoAllocation.Models;

namespace CarNoAllocation.Controllers
{
    public class tblFancyNumsController : Controller
    {
        private dbCarNumberAllotmentSystemEntities1 db = new dbCarNumberAllotmentSystemEntities1();

        // GET: tblFancyNums
        public ActionResult Index()
        {
            var tblFancyNums = db.tblFancyNums.Include(t => t.tblCarRegistrationDetail);
            return View(tblFancyNums.ToList());
        }

        // GET: tblFancyNums/Details/5
        public ActionResult Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblFancyNum tblFancyNum = db.tblFancyNums.Find(id);
            if (tblFancyNum == null)
            {
                return HttpNotFound();
            }
            return View(tblFancyNum);
        }

        // GET: tblFancyNums/Create
        public ActionResult Create()
        {
            ViewBag.vUniqueId = new SelectList(db.tblCarRegistrationDetails, "vUniqueId", "vRegistrationNum");
            return View();
        }

        // POST: tblFancyNums/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "vUniqueId,vFancyNum")] tblFancyNum tblFancyNum)
        {
            string user = Session["UserID"].ToString();

            var ab = (from e in db.tblCarRegistrationDetails where (e.vUserId == user) select e).FirstOrDefault();
            tblFancyNum.vUniqueId = ab.vUniqueId;
           // tblFancyNum.vFancyNum = ab.vRegistrationNum;
           // if (ModelState.IsValid)
           // {
            //    db.tblFancyNums.Add(tblFancyNum);
            //    db.SaveChanges();
            //    return RedirectToAction("Index");
//}
        
            ViewBag.vUniqueId = new SelectList(db.tblCarRegistrationDetails, "vUniqueId", "vRegistrationNum", tblFancyNum.vUniqueId);
            return RedirectToAction("Userpage","tblCarRegistrationDetails");
        }

        // GET: tblFancyNums/Edit/5
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblFancyNum tblFancyNum = db.tblFancyNums.Find(id);
            if (tblFancyNum == null)
            {
                return HttpNotFound();
            }
            ViewBag.vUniqueId = new SelectList(db.tblCarRegistrationDetails, "vUniqueId", "vRegistrationNum", tblFancyNum.vUniqueId);
            return View(tblFancyNum);
        }

        // POST: tblFancyNums/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "vUniqueId,vFancyNum")] tblFancyNum tblFancyNum)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tblFancyNum).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.vUniqueId = new SelectList(db.tblCarRegistrationDetails, "vUniqueId", "vRegistrationNum", tblFancyNum.vUniqueId);
            return View(tblFancyNum);
        }

        // GET: tblFancyNums/Delete/5
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblFancyNum tblFancyNum = db.tblFancyNums.Find(id);
            if (tblFancyNum == null)
            {
                return HttpNotFound();
            }
            return View(tblFancyNum);
        }

        // POST: tblFancyNums/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            tblFancyNum tblFancyNum = db.tblFancyNums.Find(id);
            db.tblFancyNums.Remove(tblFancyNum);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
