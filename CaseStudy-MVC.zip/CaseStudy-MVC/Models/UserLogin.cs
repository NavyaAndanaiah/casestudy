﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CarNoAllocation.Models
{
    public class UserLogin
    {

              [Required(ErrorMessage = "Required")]
              public string vUserId { get; set; }

              [Required(ErrorMessage = "Required")]
              public string vPassword { get; set; }
    }
}