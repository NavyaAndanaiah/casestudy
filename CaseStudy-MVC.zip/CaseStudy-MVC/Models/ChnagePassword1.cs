﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace CarNoAllocation.Models
{
    public class ChnagePassword1
    {
        [Required(ErrorMessage = "Required")]
        [DataType(DataType.Password)]


        public string oldPassword { get; set; }
        [Required(ErrorMessage = "Required")]


        [DataType(DataType.Password)]
        public string newPassword { get; set; }


           [NotMapped]
        [Required(ErrorMessage = "please enter to confirm password")]
        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("newPassword", ErrorMessage = "The password and confirmation do not match.")]
        public string ConfirmPassword { get; set; }
    }
}